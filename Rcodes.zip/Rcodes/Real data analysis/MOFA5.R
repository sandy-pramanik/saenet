
# load("/Users/mystaff/research/salasso/code/1-23-20/MOFA/CLL_data.RData")
load('/home/sandy.tamu_16/salasso/10-30-19/CLL_data.RData')

source('SAEnet8-12-21.R')

gam.al.seq = seq(.01, 2, by = .01)
gam.sal.seq = seq(.1, 1, by = .1)
nCore.eachmethod = 5
iter.max = 5

## responses
## D_002 (responses from 5 doses of 'ibrutinib')

# detecting NA's from response
y.mat = t(CLL_data$Drugs[c('D_002_1', 'D_002_2', 'D_002_3', 'D_002_4', 'D_002_5'),])
y.NA.indx = numeric()
for(k in 1:ncol(y.mat)){
  t = which(is.na(y.mat[,k]))
  y.NA.indx = union( y.NA.indx, t)
}

# detecting NA's from design mat
y.drug.indx = which(row.names(CLL_data$Drugs)==c('D_002_1', 'D_002_2', 'D_002_3', 'D_002_4', 'D_002_5'))
X.mat = t(rbind(CLL_data$mRNA, CLL_data$Methylation, CLL_data$Drugs[-y.drug.indx,]))

Xmat.NA.indx = numeric()
for(k in 1:ncol(X.mat)){
  t = which(is.na(X.mat[,k]))
  Xmat.NA.indx = union( Xmat.NA.indx, t)
}

# update y.index NA's
y.NA.indx = union(y.NA.indx, Xmat.NA.indx)

y.mat.fit = y.mat[-y.NA.indx,]
X.mat.fit = X.mat[-y.NA.indx,]

nGroups = 3
# groups = rep(1:nGroups, each = 100)
groups = rep(1:nGroups,
             c(nrow(CLL_data$mRNA), nrow(CLL_data$Methylation),
               (nrow(CLL_data$Drugs) -5)))
grp.id.list = lapply(X = 1:nGroups, FUN = function(X){which(groups==X)})

n = nrow(X.mat.fit)
p = ncol(X.mat.fit)
R = 100
n.train = floor(.7*n)
n.test = n - n.train

j = 5   # sets the response

registerDoParallel(cores = 11)
MOFA5 = foreach(r = 1:R, .combine = 'mycombine_rep_delta', .multicombine = T) %dopar% {
  
  set.seed((j-1)*R+r)
  test.set = sample(x = 1:n, size = n.test)   # training-test partition
  
  ################################ response variable, design matrix ################################
  X.fit.train = X.mat.fit[-test.set,]
  y.fit.train = y.mat.fit[-test.set,j]
  
  
  ################################ Lasso ################################
  cv.l = cv.glmnet(x = X.fit.train, y = y.fit.train, 
                   intercept = T, standardize = T, keep = T)
  coef.l = as.numeric(coef(cv.l$glmnet.fit, s = cv.l$lambda.min))
  intercept.l = coef.l[1]
  betahat.l = coef.l[-1]
  
  
  ################################ A-Lasso ################################
  if(sum(betahat.l==0)==p){
    
    intercept.al = mean(y.fit.train)
    betahat.al = numeric(p)
    
  }else{
    
    wts.init.al = 1/abs(betahat.l)
    tune.al = function(gam){
      
      wts.al = wts.init.al^gam
      
      cv.al = cv.glmnet(x = X.fit.train, y = y.fit.train,
                        penalty.factor = wts.al,
                        intercept = T, standardize = T,
                        foldid = cv.l$foldid)
      c(cv.al$lambda.min, min(cv.al$cvm))
    }
    
    cv.al.df = t(mcmapply(FUN = tune.al, gam = gam.al.seq, 
                          mc.cores = nCore.eachmethod))
    colnames(cv.al.df) = c('lambda.min', 'cvm')
    opt.indx.al = which.min(cv.al.df[,"cvm"])
    opt.gamma.al = gam.al.seq[opt.indx.al]
    lambda.cv.al = as.numeric(cv.al.df[opt.indx.al, "lambda.min"])
    
    # estimate weights based on opt gamma
    wts.al = wts.init.al^opt.gamma.al
    out.al = glmnet(x = X.fit.train, y = y.fit.train,
                    lambda = lambda.cv.al,
                    penalty.factor = wts.al,
                    intercept = T, standardize = T)
    coef.al = as.numeric(coef(out.al, s = lambda.cv.al))
    intercept.al = coef.al[1]
    betahat.al = coef.al[-1]
  }
  
  
  ################################ grpreg ################################
  cv.g = cv.grpreg(X = X.fit.train, y = y.fit.train, group = groups,
                   family = "gaussian", penalty = "grLasso",
                   alpha = .95, fold = cv.l$foldid)
  coef.g = as.numeric(coef(cv.g))
  intercept.grpreg = coef.g[1]
  betahat.grpreg = coef.g[-1]
  
  
  ################################ fwelnet ################################
  zmat = matrix(0, nrow = p, ncol = nGroups)
  for (d in 1:nGroups) zmat[grp.id.list[[d]], d] = 1
  cv.f = cv.fwelnet(x = X.fit.train, y = y.fit.train,
                    z = zmat, standardize = T, foldid = cv.l$foldid)
  intercept.f = as.numeric(cv.f$glmfit$a0[which(cv.f$lambda==cv.f$lambda.min)])
  betahat.f = as.numeric(cv.f$glmfit$beta[,which(cv.f$lambda==cv.f$lambda.min)])
  
  
  ################################ graper ################################
  out.graper = graper(X = X.fit.train, y = y.fit.train,
                      annot = as.factor(groups),
                      intercept = T, standardize = T, verbose = F)
  intercept.graper = as.numeric(out.graper$intercept)
  betahat.graper = as.numeric(out.graper$EW_beta)
  
  
  ################################ SA-Lasso ################################
  if(sum(betahat.l==0)==p){
    
    intercept.sal = c(intercept.l, rep(mean(y.fit.train), iter.max))
    betahat.sal = cbind(betahat.l, matrix(nrow = p, ncol = iter.max))
    
  }else{
    
    intercept.sal = c(intercept.l, rep(NA, iter.max))
    betahat.sal = cbind(betahat.l, matrix(nrow = p, ncol = iter.max))
    
    itr.sal = 0
    while(itr.sal<iter.max){
      
      # print(itr.sal + 1)
      
      wts.init.sal = rep(NA, p)
      for (d in 1:nGroups) wts.init.sal[grp.id.list[[d]]] = 1/mean(abs(betahat.sal[grp.id.list[[d]],
                                                                                   itr.sal + 1]))
      
      if(any(sum(betahat.sal[, itr.sal + 1]!=0)==0, sum(wts.init.sal!=Inf)==0)){
        
        itr.sal = itr.sal + 1
        intercept.sal[itr.sal + 1] = mean(y.fit.train)
        betahat.sal[, itr.sal + 1] = numeric(p)
        
      }else{
        
        tune.sal = function(gam){
          
          wts.sal = wts.init.sal^gam
          
          cv.sal = cv.glmnet(x = X.fit.train, y = y.fit.train, 
                             penalty.factor = wts.sal,
                             intercept = T, standardize = T,
                             foldid = cv.l$foldid)
          
          c(cv.sal$lambda.min, min(cv.sal$cvm))
        }
        
        cv.sal.df = t(mcmapply(FUN = tune.sal, gam = gam.sal.seq, 
                               mc.cores = nCore.eachmethod))
        colnames(cv.sal.df) = c('lambda.min', 'cvm')
        opt.indx.sal = which.min(cv.sal.df[,"cvm"])
        opt.gamma.sal = gam.sal.seq[opt.indx.sal]
        lambda.cv.sal = as.numeric(cv.sal.df[opt.indx.sal, "lambda.min"])
        
        # estimate weights based on opt gamma
        wts.sal = wts.init.sal^opt.gamma.sal
        out.sal = glmnet(x = X.fit.train, y = y.fit.train,
                         lambda = lambda.cv.sal,
                         penalty.factor = wts.sal,
                         intercept = T, standardize = T)
        
        itr.sal = itr.sal + 1
        coef.sal = as.numeric(coef(out.sal, s = lambda.cv.sal))
        intercept.sal[itr.sal + 1] = coef.sal[1]
        betahat.sal[, itr.sal + 1] = coef.sal[-1]
      }
    }
  }
  
  
  ################################ SA-Enet ################################
  out.SAEnet = SAEnet(y = y.fit.train, X = X.fit.train, #gamma.seq = 1,
                      structure.info = list('grp' = groups),
                      nIteration = iter.max, std.y = F, std.X = T,
                      foldid = cv.l$foldid, nCore = nCore.eachmethod,
                      verbose = F)
  intercept.SAEnet = out.SAEnet$intercept
  betahat.SAEnet = out.SAEnet$betahat
  
  
  # model selection
  betahat.l.10 = as.numeric(betahat.l!=0)
  betahat.al.10 = as.numeric(betahat.al!=0)
  betahat.grpreg.10 = as.numeric(betahat.grpreg!=0)
  betahat.f.10 = as.numeric(betahat.f!=0)
  betahat.graper.10 = as.numeric(betahat.graper!=0)
  betahat.sal.10 = ifelse(betahat.sal!=0, 1, 0)
  betahat.SAEnet.10 = ifelse(betahat.SAEnet!=0, 1, 0)
  
  
  # estimated y on the test set
  yhat.l = intercept.l + as.numeric(X.mat.fit[test.set,]%*%betahat.l)
  yhat.al = intercept.al + as.numeric(X.mat.fit[test.set,]%*%betahat.al)
  yhat.grpreg = intercept.grpreg + as.numeric(X.mat.fit[test.set,]%*%betahat.grpreg)
  yhat.f = intercept.f + as.numeric(X.mat.fit[test.set,]%*%betahat.f)
  yhat.graper = intercept.graper + as.numeric(X.mat.fit[test.set,]%*%betahat.graper)
  yhat.sal = t(intercept.sal + t(X.mat.fit[test.set,]%*%betahat.sal))
  yhat.SAEnet = t(intercept.SAEnet + t(X.mat.fit[test.set,]%*%betahat.SAEnet))
  
  
  # mean squared prediction error on the test set
  mspe.l = mean((y.mat.fit[test.set,j] - yhat.l)^2)
  mspe.al = mean((y.mat.fit[test.set,j] - yhat.al)^2)
  mspe.grpreg = mean((y.mat.fit[test.set,j] - yhat.grpreg)^2)
  mspe.f = mean((y.mat.fit[test.set,j] - yhat.f)^2)
  mspe.graper = mean((y.mat.fit[test.set,j] - yhat.graper)^2)
  mspe.sal = colMeans((y.mat.fit[test.set,j] - yhat.sal)^2)
  mspe.SAEnet = colMeans((y.mat.fit[test.set,j] - yhat.SAEnet)^2)
  
  print(r)
  
  list(c(mspe.l, mspe.al, mspe.grpreg, mspe.f,
         mspe.graper, mspe.sal, mspe.SAEnet),
       cbind(betahat.l.10, betahat.al.10, betahat.grpreg.10, 
             betahat.f.10, betahat.graper.10, betahat.sal.10,
             betahat.SAEnet.10),
       betahat.l, betahat.al, betahat.grpreg, betahat.f, 
       betahat.graper, betahat.sal, betahat.SAEnet)
}

names(MOFA5) = c('mspe', 'inclusion.prob',
                 'betahat.l', 'betahat.al', 'betahat.grpreg', 'betahat.f', 
                 'betahat.graper', 'betahat.sal', 'betahat.SAEnet')

d = apply(MOFA5$inclusion.prob, 2,
          FUN = function(v){
            
            v.ret = numeric(p)
            for(r in 1:R) v.ret = v.ret + v[(((r-1)*p)+1):(r*p)]
            
            v.ret/R
          })
MOFA5$inclusion.prob = d

colnames(MOFA5$mspe) = colnames(MOFA5$inclusion.prob) =
  c('Lasso', 'A.Lasso', 'grpreg', 'fwelnet', 'graper',
    paste('SA.Lasso', 0:iter.max, sep = ''),
    paste('SA.Enet', 0:iter.max, sep = ''))

save(MOFA5, file = "MOFA5.RData")





