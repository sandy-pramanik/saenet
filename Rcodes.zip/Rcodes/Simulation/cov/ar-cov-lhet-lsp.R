
source('SAEnet8-12-21.R')

delta_e.seq = c(.5, .75, 1)   # difficulty in estimation; s/n ratio
iter.max = 5
R = 100
gam.al.seq = seq(.01, 2, by = .01)
gam.sal.seq = seq(.1, 1, by = .1)
nCore.eachmethod = 6

################################ basic parameters ################################
p = 300   # number of predictor variables
a = 2.6
b = .05
set.seed(1)
u = sort(runif(p, -3, 3))
beta.true = beta.true.10 = rbinom(p, 1, 1/(1+exp(a-b*u)))
nsignal.total = sum(beta.true.10)
round(mean(beta.true.10),2)
# plot(beta.true)

# noise standard deviation
sigma = .2

registerDoParallel(cores = 3)
ar.cov.lhet.lsp = foreach(delta_e = delta_e.seq, .combine = 'mycombine_rep', .multicombine = T) %dopar% {
  
  nObs = ceiling(nsignal.total/delta_e)  # sample size
  
  ################################ Replicated studies ################################
  registerDoParallel(cores = 3)
  out_delta_e = foreach(r = 1:R, .combine = 'mycombine_rep_delta', .multicombine = T) %dopar% {
    
    set.seed(r)
    
    ################################ data generation ################################
    # design matrix
    Xmat = design("ar", nObs, p)
    
    # Generating response variable
    yobs = as.numeric(Xmat%*%beta.true + rnorm(nObs, 0, sigma))
    
    
    ################################ Lasso ################################
    cv.l = cv.glmnet(x = Xmat, y = yobs, 
                     intercept = T, standardize = F, keep = T)
    betahat.l = as.numeric(coef(cv.l$glmnet.fit, s = cv.l$lambda.min))[-1]
    
    # mcc
    betahat.l.10 = as.numeric(betahat.l!=0)
    t1 = matrix(data = 0, nrow = 2, ncol = 2)
    colnames(t1) = c(0,1)
    rownames(t1) = c(0,1)
    t1[1,1] = sum((1- beta.true.10)*(1- betahat.l.10))
    t1[1,2] = sum((1- beta.true.10)*betahat.l.10)
    t1[2,1] = sum(beta.true.10*(1- betahat.l.10))
    t1[2,2] = sum(beta.true.10*betahat.l.10)
    t11 = sqrt(t1[1,1]+t1[1,2])
    t12 = sqrt(t1[1,1]+t1[2,1])
    t21 = sqrt(t1[2,2]+t1[1,2])
    t22 = sqrt(t1[2,2]+t1[2,1])
    if(any(t11==0, t12==0, t21==0, t22==0)){
      mcc.l = 0
    }else{
      mcc.l = (t1[1,1]*t1[2,2] - t1[1,2]*t1[2,1])/(t11*t12*t21*t22)
    }
    
    
    ################################ A-Lasso ################################
    if(sum(betahat.l==0)==p){
      
      betahat.al = numeric(p)
      
    }else{
      
      wts.init.al = 1/abs(betahat.l)
      tune.al = function(gam){
        
        wts.al = wts.init.al^gam
        
        cv.al = cv.glmnet(x = Xmat, y = yobs,
                          penalty.factor = wts.al,
                          intercept = T, standardize = F,
                          foldid = cv.l$foldid)
        c(cv.al$lambda.min, min(cv.al$cvm))
      }
      
      cv.al.df = t(mcmapply(FUN = tune.al, gam = gam.al.seq, 
                            mc.cores = nCore.eachmethod))
      colnames(cv.al.df) = c('lambda.min', 'cvm')
      opt.indx.al = which.min(cv.al.df[,"cvm"])
      opt.gamma.al = gam.al.seq[opt.indx.al]
      lambda.cv.al = as.numeric(cv.al.df[opt.indx.al, "lambda.min"])
      
      # estimate weights based on opt gamma
      wts.al = wts.init.al^opt.gamma.al
      out.al = glmnet(x = Xmat, y = yobs, lambda = lambda.cv.al,
                      penalty.factor = wts.al,
                      intercept = T, standardize = F)
      betahat.al = as.vector(coef(out.al, s = lambda.cv.al))[-1]
    }
    
    # mcc
    betahat.al.10 = as.numeric(betahat.al!=0)
    t1 = matrix(data = 0, nrow = 2, ncol = 2)
    colnames(t1) = c(0,1)
    rownames(t1) = c(0,1)
    t1[1,1] = sum((1- beta.true.10)*(1- betahat.al.10))
    t1[1,2] = sum((1- beta.true.10)*betahat.al.10)
    t1[2,1] = sum(beta.true.10*(1- betahat.al.10))
    t1[2,2] = sum(beta.true.10*betahat.al.10)
    t11 = sqrt(t1[1,1]+t1[1,2])
    t12 = sqrt(t1[1,1]+t1[2,1])
    t21 = sqrt(t1[2,2]+t1[1,2])
    t22 = sqrt(t1[2,2]+t1[2,1])
    if(any(t11==0, t12==0, t21==0, t22==0)){
      mcc.al = 0
    }else{
      mcc.al = (t1[1,1]*t1[2,2] - t1[1,2]*t1[2,1])/(t11*t12*t21*t22)
    }
    
    
    ################################ fwelnet ################################
    zmat = matrix(u)
    cv.f = cv.fwelnet(Xmat, yobs, zmat, standardize = F, foldid = cv.l$foldid)
    betahat.f = cv.f$glmfit$beta[,which(cv.f$lambda==cv.f$lambda.min)]
    
    # mcc
    betahat.f.10 = as.numeric(betahat.f!=0)
    t1 = matrix(data = 0, nrow = 2, ncol = 2)
    colnames(t1) = c(0,1)
    rownames(t1) = c(0,1)
    t1[1,1] = sum((1- beta.true.10)*(1- betahat.f.10))
    t1[1,2] = sum((1- beta.true.10)*betahat.f.10)
    t1[2,1] = sum(beta.true.10*(1- betahat.f.10))
    t1[2,2] = sum(beta.true.10*betahat.f.10)
    t11 = sqrt(t1[1,1]+t1[1,2])
    t12 = sqrt(t1[1,1]+t1[2,1])
    t21 = sqrt(t1[2,2]+t1[1,2])
    t22 = sqrt(t1[2,2]+t1[2,1])
    if(any(t11==0, t12==0, t21==0, t22==0)){
      mcc.f = 0
    }else{
      mcc.f = (t1[1,1]*t1[2,2] - t1[1,2]*t1[2,1])/(t11*t12*t21*t22)
    }
    
    
    ################################ SA-Lasso ################################
    u.c = mean(u)
    u.sca = sd(u)
    u.std = (u - u.c)/u.sca
    
    betahat.sal = cbind(betahat.l, matrix(nrow = p, ncol = iter.max))
    
    itr.sal = 0
    while(itr.sal<iter.max){
      
      if(sum(betahat.sal[, itr.sal + 1]==0)==p){
        
        tune.sal = function(gam){
          
          if(gam==1){
            
            opt.out = nlminb(start = c(0,0),
                             lower = c(-30,-30), upper = c(30,30),
                             objective = function(x){
                               
                               -(p*x[1])
                               
                             }, control = list(eval.max = 5000, iter.max = 5000))
            tau.opt = opt.out$par
            
          }else if((gam>0) && (gam<1)){
            
            opt.out = nlminb(start = c(0,0),
                             lower = c(-30,-30), upper = c(30,30),
                             objective = function(x){
                               
                               -(sum(exp((1-(1/gam))*(x[1] + x[2]*u.std))))/(1-(1/gam))
                               
                             }, control = list(eval.max = 5000, iter.max = 5000))
            tau.opt = opt.out$par
          }
          
          wts.sal = exp(tau.opt[1] + tau.opt[2]*u.std)
          
          cv.sal = cv.glmnet(x = Xmat, y = yobs, 
                             penalty.factor = wts.sal,
                             intercept = T, standardize = F,
                             foldid = cv.l$foldid)
          
          c(cv.sal$lambda.min, min(cv.sal$cvm))
        }
        
        cv.sal.df = t(mcmapply(FUN = tune.sal, gam = gam.sal.seq, 
                               mc.cores = nCore.eachmethod))
        colnames(cv.sal.df) = c('lambda.min', 'cvm')
        opt.indx.sal = which.min(cv.sal.df[,"cvm"])
        opt.gamma.sal = gam.sal.seq[opt.indx.sal]
        lambda.cv.sal = as.numeric(cv.sal.df[opt.indx.sal, "lambda.min"])
        
        # estimate weights based on opt gamma
        if(opt.gamma.sal==1){
          
          opt.out = nlminb(start = c(0,0),
                           lower = c(-30,-30), upper = c(30,30),
                           objective = function(x){
                             
                             -(p*x[1])
                             
                           }, control = list(eval.max = 5000, iter.max = 5000))
          tau.opt = opt.out$par
          
        }else if((opt.gamma.sal>0) && (opt.gamma.sal<1)){
          
          opt.out = nlminb(start = c(0,0),
                           lower = c(-30,-30), upper = c(30,30),
                           objective = function(x){
                             
                             -(sum(exp((1-(1/opt.gamma.sal))*(x[1] + x[2]*u.std))))/(1-(1/opt.gamma.sal))
                             
                           }, control = list(eval.max = 5000, iter.max = 5000))
          tau.opt = opt.out$par
        }
        
        wts.sal = exp(tau.opt[1] + tau.opt[2]*u.std)
        
      }else{
        
        Sbeta = which(betahat.sal[, itr.sal + 1]!=0)
        
        tune.sal = function(gam){
          
          if(gam==1){
            
            opt.out = nlminb(start = c(0,0),
                             lower = c(-30,-30), upper = c(30,30),
                             objective = function(x){
                               
                               sum(exp(x[1] + x[2]*u.std[Sbeta])*abs(betahat.sal[Sbeta, itr.sal + 1])) - (p*x[1])
                               
                             }, control = list(eval.max = 5000, iter.max = 5000))
            tau.opt = opt.out$par
            
          }else if((gam>0) && (gam<1)){
            
            opt.out = nlminb(start = c(0,0),
                             lower = c(-30,-30), upper = c(30,30),
                             objective = function(x){
                               
                               sum(exp(x[1] + x[2]*u.std[Sbeta])*abs(betahat.sal[Sbeta, itr.sal + 1])) - 
                                 (sum(exp((1-(1/gam))*(x[1] + x[2]*u.std))))/(1-(1/gam))
                               
                             }, control = list(eval.max = 5000, iter.max = 5000))
            tau.opt = opt.out$par
          }
          
          wts.sal = exp(tau.opt[1] + tau.opt[2]*u.std)
          
          cv.sal = cv.glmnet(x = Xmat, y = yobs, 
                             penalty.factor = wts.sal,
                             intercept = T, standardize = F,
                             foldid = cv.l$foldid)
          
          c(cv.sal$lambda.min, min(cv.sal$cvm))
        }
        
        cv.sal.df = t(mcmapply(FUN = tune.sal, gam = gam.sal.seq, 
                               mc.cores = nCore.eachmethod))
        colnames(cv.sal.df) = c('lambda.min', 'cvm')
        opt.indx.sal = which.min(cv.sal.df[,"cvm"])
        opt.gamma.sal = gam.sal.seq[opt.indx.sal]
        lambda.cv.sal = as.numeric(cv.sal.df[opt.indx.sal, "lambda.min"])
        
        # estimate weights based on opt gamma
        if(opt.gamma.sal==1){
          
          opt.out = nlminb(start = c(0,0),
                           lower = c(-30,-30), upper = c(30,30),
                           objective = function(x){
                             
                             sum(exp(x[1] + x[2]*u.std[Sbeta])*abs(betahat.sal[Sbeta, itr.sal + 1])) - (p*x[1])
                             
                           }, control = list(eval.max = 5000, iter.max = 5000))
          tau.opt = opt.out$par
          
        }else if((opt.gamma.sal>0) && (opt.gamma.sal<1)){
          
          opt.out = nlminb(start = c(0,0),
                           lower = c(-30,-30), upper = c(30,30),
                           objective = function(x){
                             
                             sum(exp(x[1] + x[2]*u.std[Sbeta])*abs(betahat.sal[Sbeta, itr.sal + 1])) - 
                               (sum(exp((1-(1/opt.gamma.sal))*(x[1] + x[2]*u.std))))/(1-(1/opt.gamma.sal))
                             
                           }, control = list(eval.max = 5000, iter.max = 5000))
          tau.opt = opt.out$par
        }
        
        wts.sal = exp(tau.opt[1] + tau.opt[2]*u.std)
      }
      
      out.sal = glmnet(x = Xmat, y = yobs, lambda = lambda.cv.sal,
                       penalty.factor = wts.sal,
                       intercept = T, standardize = F)
      
      itr.sal = itr.sal + 1
      betahat.sal[, itr.sal + 1] = as.vector(coef(out.sal, s = lambda.cv.sal))[-1]
      
      # print(itr.sal)
    }
    
    # mcc
    betahat.sal.10 = ifelse(betahat.sal!=0, 1, 0)
    mcc.sal = apply(betahat.sal.10, 2, 
                    FUN = function(v){
                      
                      t1 = matrix(data = 0, nrow = 2, ncol = 2)
                      colnames(t1) = c(0,1)
                      rownames(t1) = c(0,1)
                      t1[1,1] = sum((1- beta.true.10)*(1- v))
                      t1[1,2] = sum((1- beta.true.10)*v)
                      t1[2,1] = sum(beta.true.10*(1- v))
                      t1[2,2] = sum(beta.true.10*v)
                      t11=sqrt(t1[1,1]+t1[1,2])
                      t12=sqrt(t1[1,1]+t1[2,1])
                      t21=sqrt(t1[2,2]+t1[1,2])
                      t22=sqrt(t1[2,2]+t1[2,1])
                      if(any(t11==0, t12==0, t21==0, t22==0)){
                        return(0)
                      }else{
                        return((t1[1,1]*t1[2,2] - t1[1,2]*t1[2,1])/(t11*t12*t21*t22))
                      }
                    })
    
    
    ################################ SA-Enet ################################
    out.SAEnet = SAEnet(y = yobs, X = Xmat, #gamma.seq = 1,
                        structure.info = list('cov' = u),
                        nIteration = iter.max, std.y = F, std.X = F,
                        foldid = cv.l$foldid, nCore = nCore.eachmethod,
                        verbose = F)
    betahat.SAEnet = out.SAEnet$betahat
    
    # mcc
    betahat.SAEnet.10 = ifelse(betahat.SAEnet!=0, 1, 0)
    mcc.SAEnet = apply(betahat.SAEnet.10, 2, 
                       FUN = function(v){
                         
                         t1 = matrix(data = 0, nrow = 2, ncol = 2)
                         colnames(t1) = c(0,1)
                         rownames(t1) = c(0,1)
                         t1[1,1] = sum((1- beta.true.10)*(1- v))
                         t1[1,2] = sum((1- beta.true.10)*v)
                         t1[2,1] = sum(beta.true.10*(1- v))
                         t1[2,2] = sum(beta.true.10*v)
                         t11=sqrt(t1[1,1]+t1[1,2])
                         t12=sqrt(t1[1,1]+t1[2,1])
                         t21=sqrt(t1[2,2]+t1[1,2])
                         t22=sqrt(t1[2,2]+t1[2,1])
                         if(any(t11==0, t12==0, t21==0, t22==0)){
                           return(0)
                         }else{
                           return((t1[1,1]*t1[2,2] - t1[1,2]*t1[2,1])/(t11*t12*t21*t22))
                         }
                       })
    
    print(r)
    
    list(c(mean((betahat.l - beta.true)^2),   # Lasso
           mean((betahat.al - beta.true)^2),   # A-Lasso
           mean((betahat.f - beta.true)^2),   # fwelnet
           colMeans((betahat.sal - beta.true)^2),   # SA-Lasso
           colMeans((betahat.SAEnet - beta.true)^2)   # SA-Enet
    ),
    c(mcc.l, mcc.al, mcc.f, mcc.sal, mcc.SAEnet),
    betahat.l, betahat.al, betahat.f, betahat.sal, betahat.SAEnet)
  }
  
  print(delta_e)
  
  
  ################################ summarizing behavior ################################
  summary.list_delta = vector('list', length(out_delta_e))
  for(k in 1:(length(out_delta_e)-2)){
    
    summary.list_delta[[k]] = list(colMeans(out_delta_e[[k]]),
                                   apply(out_delta_e[[k]], 2, sd))
  }
  for(k in (length(out_delta_e)-1):length(out_delta_e)){
    
    summary.list_delta[[k]] = list(apply(out_delta_e[[k]], 2:3, mean),
                                   apply(out_delta_e[[k]], 2:3, sd))
  }
  
  summary.list_delta
}

names(ar.cov.lhet.lsp) = c('mse', 'mcc', 
                            'Lasso', 'A.Lasso', 'fwelnet', 
                            'SA.Lasso', 'SA.Enet')
for(k in 1:length(ar.cov.lhet.lsp)){
  
  names(ar.cov.lhet.lsp[[k]]) = c('avg.mc', 'sd.mc')
  
  if(any(k==1:2)){
    colnames(ar.cov.lhet.lsp[[k]][[1]]) = colnames(ar.cov.lhet.lsp[[k]][[2]]) = 
      c('Lasso', 'A.Lasso','fwelnet',
        paste('SA.Lasso', 0:iter.max, sep = ''),
        paste('SA.Enet', 0:iter.max, sep = ''))
    ar.cov.lhet.lsp[[k]][[1]] = cbind.data.frame('delta_e' = delta_e.seq,
                                                  ar.cov.lhet.lsp[[k]][[1]])
    ar.cov.lhet.lsp[[k]][[2]] = cbind.data.frame('delta_e' = delta_e.seq,
                                                  ar.cov.lhet.lsp[[k]][[2]])
  }
}

ar.cov.lhet.lsp = c(ar.cov.lhet.lsp, list('beta.true' = beta.true))

save(ar.cov.lhet.lsp, file = 'ar-cov-lhet-lsp.RData')


