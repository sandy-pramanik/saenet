
source("functions.R")

alpha2 = .4
alpha1.seq = exp(seq(log(.01), log(2), length.out = 50))
nIteration = 2
nCore = 55

#### prediction based on AMP ####
#### basic parameters ####
p = 10000  # no. of parameters
delta_s = .1  # proportion of signal
delta = 0.64  # ratio of n/p

nGroups = 3   # total number of groups
nsignal.total = floor(p*delta_s)

# signals
abs.signal.strength = seq(1, 2, length.out = nGroups-1)
nsignal.nononull.groups = rep(floor(nsignal.total/(nGroups-1)), nGroups-1)
nsignal.nononull.groups[1] = nsignal.total - sum(nsignal.nononull.groups[-1])
all.abs.signals = rep(abs.signal.strength, nsignal.nononull.groups)

spbetween.null = .05
spbetween.nonnull = rep(round((1-spbetween.null)/(nGroups-1), 2), nGroups-1)
spbetween.groups = c(spbetween.null, spbetween.nonnull)
spbetween.groups[1] = 1 - sum(spbetween.groups[-1])
nsignal.groups = floor(spbetween.groups*nsignal.total)
nsignal.groups[1] = nsignal.total - sum(nsignal.groups[-1])   # number of signals in each group

spwithin.nonnull = rep(.9, nGroups-1)
group.size.nonnull = floor(nsignal.groups[-1]/spwithin.nonnull)
group.size = c(p-sum(group.size.nonnull), group.size.nonnull)

# group indices
groups = rep(1:nGroups, group.size)
grp.id.list = lapply(X = 1:nGroups, FUN = function(X){which(groups==X)})

sigma = sqrt(.2)  # noise sd
eps = 1e-9  # tolerance in state evolution

#### Generating B0 and Z ####
R = 100
B0 = Z = matrix(NA, R, p)
for (r in 1:R) {
  
  set.seed(r)
  
  beta.true = NULL
  abs.signals.left = all.abs.signals
  for(d in nGroups:1){
    
    beta.true_d = numeric(group.size[d])
    if(nsignal.groups[d]>0){
      
      if(d>1){
        
        signal.id_d = sample(x = 1:group.size[d], size = nsignal.groups[d])
        abs.signals_d = which(abs.signals.left==abs.signal.strength[d-1])[1:nsignal.groups[d]]
        beta.true_d[signal.id_d] = abs.signals.left[abs.signals_d]*
          (2*rbinom(nsignal.groups[d], 1, .5) - 1)
        abs.signals.left = abs.signals.left[-abs.signals_d]
        
      }else{
        
        signal.id_d = sample(x = 1:group.size[d], size = nsignal.groups[d])
        beta.true_d[signal.id_d] = abs.signals.left*
          (2*rbinom(nsignal.groups[d], 1, .5) - 1)
        abs.signals.left = abs.signals.left[-abs.signals_d]
      }
    }
    
    beta.true = c(beta.true_d, beta.true)
  }
  B0[r,] = beta.true
  Z[r,] = rnorm(p)
}
B0v = as.vector(B0) 
Zv = as.vector(Z)

amp.mse.all = lambda1.all = lambda2.all = tau.opt.id = NULL
for(itr in 0:nIteration){
  
  if(itr==0){
    
    omega = rep(1, nGroups)
    
    registerDoParallel(cores = nCore)
    mse.summary = foreach::foreach(alpha1 = alpha1.seq, .combine = 'rbind') %dopar% {
      
      #### State evolution  ####
      tau.new = sqrt(sigma^2 + mean(B0v^2)/delta)
      converged = F
      while (!converged) {
        
        tau.old = tau.new
        eta.vec = (pmax(abs(B0v + tau.new*Zv) - alpha1*tau.new, 0)*
                     sign(B0v + tau.new*Zv))/(1 + 2*alpha2*tau.new)
        tau.new = sqrt(mean((eta.vec-B0v)^2)/delta + sigma^2)
        
        converged = abs(tau.new-tau.old)< eps
      }
      
      # predicted mse
      amp.mse = delta*(tau.new^2 - sigma^2)
      
      #### correspondence between (lambda1,lambda2) and (alpha1,alpha2) ####
      deriv.term = 1- mean(abs(B0v + tau.new*Zv)>(alpha1*tau.new))/
        (delta*(1 + 2*alpha2*tau.new))
      lambda1 = alpha1*tau.new*deriv.term
      lambda2 = alpha2*tau.new*deriv.term
      
      c(lambda1, lambda2, tau.new, amp.mse)
    }
    
    tau.opt.id = c(tau.opt.id, which(mse.summary[,4]==min(mse.summary[,4]))[1])
    tau.opt = mse.summary[tau.opt.id[itr+1],3]
    amp.mse.all = cbind(amp.mse.all, mse.summary[,4])
    lambda1.all = cbind(lambda1.all, mse.summary[,1])
    lambda2.all = cbind(lambda2.all, mse.summary[,2])
    
  }else{
    
    #### adaptive penalties  ####
    omega = mapply(X = 1:nGroups,
                   FUN = function(X){
                     
                     B0plusZ_X = as.numeric(B0[,grp.id.list[[X]]] +
                                              tau.opt*Z[,grp.id.list[[X]]])
                     
                     mean(abs((pmax(abs(B0plusZ_X) - (alpha1.seq[tau.opt.id[itr]]*tau.opt)/omega[X], 0)*
                                 sign(B0plusZ_X))/(1 + 2*alpha2*tau.opt)))
                   })
    
    registerDoParallel(cores = nCore)
    mse.summary = foreach::foreach(alpha1 = alpha1.seq, .combine = 'rbind') %dopar% {
      
      #### State evolution  ####
      tau.new = sqrt(sigma^2 + mean(B0v^2)/delta)
      converged = F
      while (!converged) {
        
        tau.old = tau.new
        mse.vec = mapply(X = 1:nGroups,
                         FUN = function(X){
                           
                           B0plusZ_X = as.numeric(B0[,grp.id.list[[X]]] +
                                                    tau.new*Z[,grp.id.list[[X]]])
                           
                           mean(((pmax(abs(B0plusZ_X) - (alpha1*tau.new)/omega[X], 0)*
                                    sign(B0plusZ_X))/(1 + 2*alpha2*tau.new) -
                                   as.numeric(B0[,grp.id.list[[X]]]))^2)
                         })
        
        tau.new = sqrt(sum((group.size/p)*mse.vec)/delta + sigma^2)
        
        converged = abs(tau.new-tau.old)< eps
      }
      
      # predicted mse
      amp.mse = delta*(tau.new^2 - sigma^2)
      
      #### correspondence between (lambda1,lambda2) and (alpha1,alpha2) ####
      deriv.term = 1 - sum((group.size/p)*
                             mapply(X = 1:nGroups,
                                    FUN = function(X){
                                      
                                      B0plusZ_X = as.numeric(B0[,grp.id.list[[X]]] +
                                                               tau.new*Z[,grp.id.list[[X]]])
                                      
                                      mean(abs(B0plusZ_X)>((alpha1*tau.new)/omega[X]))/
                                        (1 + 2*alpha2*tau.new)
                                      
                                    }))/delta
      lambda1 = alpha1*tau.new*deriv.term
      lambda2 = alpha2*tau.new*deriv.term
      
      c(lambda1, lambda2, tau.new, amp.mse)
    }
    
    tau.opt.id = c(tau.opt.id, which(mse.summary[,4]==min(mse.summary[,4]))[1])
    tau.opt = mse.summary[tau.opt.id[itr+1],3]
    amp.mse.all = cbind(amp.mse.all, mse.summary[,4])
    lambda1.all = cbind(lambda1.all, mse.summary[,1])
    lambda2.all = cbind(lambda2.all, mse.summary[,2])
  }
  
  print(itr)
}


#### finite sample performance based on gcdnet ####
#### basic parameters ####
p = 500  # no. of parameters
nObs = floor(p*delta)  # sample size

nsignal.total = floor(p*delta_s)

# signals
nsignal.nononull.groups = rep(floor(nsignal.total/(nGroups-1)), nGroups-1)
nsignal.nononull.groups[1] = nsignal.total - sum(nsignal.nononull.groups[-1])
all.abs.signals = rep(abs.signal.strength, nsignal.nononull.groups)

nsignal.groups = floor(spbetween.groups*nsignal.total)
nsignal.groups[1] = nsignal.total - sum(nsignal.groups[-1])   # number of signals in each group

group.size.nonnull = floor(nsignal.groups[-1]/spwithin.nonnull)
group.size = c(p-sum(group.size.nonnull), group.size.nonnull)

# group indices
groups = rep(1:nGroups, group.size)
grp.id.list = lapply(X = 1:nGroups, FUN = function(X){which(groups==X)})

simdata = lapply(X = 1:R,
                 FUN = function(X){
                   
                   set.seed(X)
                   
                   # generating true beta
                   beta.true = NULL
                   abs.signals.left = all.abs.signals
                   for(d in nGroups:1){
                     
                     beta.true_d = numeric(group.size[d])
                     if(nsignal.groups[d]>0){
                       
                       if(d>1){
                         
                         signal.id_d = sample(x = 1:group.size[d], size = nsignal.groups[d])
                         abs.signals_d = which(abs.signals.left==abs.signal.strength[d-1])[1:nsignal.groups[d]]
                         beta.true_d[signal.id_d] = abs.signals.left[abs.signals_d]*
                           (2*rbinom(nsignal.groups[d], 1, .5) - 1)
                         abs.signals.left = abs.signals.left[-abs.signals_d]
                         
                       }else{
                         
                         signal.id_d = sample(x = 1:group.size[d], size = nsignal.groups[d])
                         beta.true_d[signal.id_d] = abs.signals.left*
                           (2*rbinom(nsignal.groups[d], 1, .5) - 1)
                         abs.signals.left = abs.signals.left[-abs.signals_d]
                       }
                     }
                     
                     beta.true = c(beta.true_d, beta.true)
                   }
                   
                   Xmat = matrix(sample(x = c(-1/sqrt(nObs), 1/sqrt(nObs)),
                                        size = nObs*p,
                                        replace = T, prob = c(.5,.5)),
                                 nObs, p)   # binary design matrix
                   yobs = as.numeric(Xmat%*%beta.true + rnorm(nObs, 0, sigma))   # response
                   
                   list(beta.true, Xmat, yobs)
                 })

gcdnet.mse.all = NULL
for(itr in 0:nIteration){
  
  if(itr==0){
    
    registerDoParallel(cores = nCore)
    gcdnet.mse = foreach::foreach(a1 = seq(length(alpha1.seq)), .combine = 'c', .multicombine = T) %dopar% {
      
      L2loss = foreach::foreach(r = 1:R, .combine = 'c', .multicombine = T) %do% {
        
        fit = gcdnet::gcdnet(x = sqrt(nObs)*simdata[[r]][[2]], y = sqrt(nObs)*simdata[[r]][[3]],
                             method = 'ls', standardize = F,
                             lambda = lambda1.all[a1,itr+1], lambda2 = 2*lambda2.all[a1,itr+1])
        betahat = as.numeric(fit$beta)
        
        mean((betahat-simdata[[r]][[1]])^2)
      }
      
      mean(L2loss)
    }
    
    gcdnet.mse.all = cbind(gcdnet.mse.all, gcdnet.mse)
    
  }else{
    
    registerDoParallel(cores = nCore)
    gcdnet.mse = foreach::foreach(a1 = seq(length(alpha1.seq)), .combine = 'c', .multicombine = T) %dopar% {
      
      L2loss = foreach::foreach(r = 1:R, .combine = 'c', .multicombine = T) %do% {
        
        what = rep(1, p)
        what.mean = mean(what)
        for(t in 0:(itr-1)){
          
          fit = gcdnet::gcdnet(x = sqrt(nObs)*simdata[[r]][[2]], y = sqrt(nObs)*simdata[[r]][[3]],
                               method = 'ls', standardize = F,
                               lambda = lambda1.all[tau.opt.id[t+1],t+1]*what.mean,
                               lambda2 = 2*lambda2.all[tau.opt.id[t+1],t+1],
                               pf = what/what.mean)
          betahat = as.numeric(fit$beta)
          what = rep(NA, nGroups)
          for(d in 1:nGroups) what[d] = 1/mean(abs(betahat[grp.id.list[[d]]]))
          what = rep(pmin(what, 1e+100), group.size)
          what.mean = mean(what)
        }
        
        fit = gcdnet::gcdnet(x = sqrt(nObs)*simdata[[r]][[2]], y = sqrt(nObs)*simdata[[r]][[3]],
                             method = 'ls', standardize = F,
                             lambda = lambda1.all[a1,itr+1]*what.mean,
                             lambda2 = 2*lambda2.all[a1,itr+1],
                             pf = what/what.mean)
        betahat = as.numeric(fit$beta)
        
        mean((betahat-simdata[[r]][[1]])^2)
      }
      
      mean(L2loss)
    }
    
    gcdnet.mse.all = cbind(gcdnet.mse.all, gcdnet.mse)
  }
  
  print(itr)
}


ampSAEnet.bin.grp.alpha2_.4 = cbind.data.frame(alpha1.seq,
                                               amp.mse.all,
                                               gcdnet.mse.all)
colnames(ampSAEnet.bin.grp.alpha2_.4) = c('alpha1',
                                          # paste('lambda1.', 0:nIteration, sep = ''),
                                          # paste('lambda2.', 0:nIteration, sep = ''),
                                          # paste('tau', 0:nIteration, sep = ''),
                                          paste('amp.mse', 0:nIteration, sep = ''),
                                          paste('gcdnet.mse', 0:nIteration, sep = ''))

save(ampSAEnet.bin.grp.alpha2_.4, file = 'ampSAEnet-bin-grp-alpha2_.4.RData')


